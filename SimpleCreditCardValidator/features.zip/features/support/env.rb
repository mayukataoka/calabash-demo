# Requiring this file will import:
# * the Calabash Cucumber API,
# * the Calabash Cucumber predefined Steps,
# * and the Calabash::Formatters::Html cucumber formatter.
require "calabash-cucumber/cucumber"

# To use Calabash without the predefined Calabash Steps, uncomment these
# three lines and delete the require above.
# require "calabash-cucumber/wait_helpers"
# require "calabash-cucumber/operations"
# World(Calabash::Cucumber::Operations)
